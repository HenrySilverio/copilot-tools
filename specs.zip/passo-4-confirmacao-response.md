# Passo 4 — Confirmação — contrato de resposta e checagem de sucesso

> Unidade isolada da refatoração da camada de dados. Documento autossuficiente:
> não é necessário ler os demais passos para implementar este.
> Documento de origem: `refatoracao-datalayer-SPEC.md`.

| | |
|---|---|
| **Passo** | 4 de 5 |
| **Risco** | ALTO — muda comportamento |
| **Depende de** | **Passo 3 obrigatoriamente concluído.** O `ConfirmacaoFeatureService` precisa existir para receber `verificarSucesso`. |
| **Bloqueia** | Nada. |
| **Muda comportamento?** | **SIM — este passo corrige um bug.** Hoje o store navega para a tela de conclusão mesmo quando o backend recusa e devolve HTTP 200. Depois, `sucesso: false` cai em estado de erro. Trate como mudança funcional em homologação, não como refactor neutro. |

---

## 1. Contrato do BFF

Anexe abaixo o trecho do OpenAPI extraído do Swagger, **antes de começar a implementação**. Cole somente o path, a operation e os schemas realmente usados — nunca o YAML monolítico inteiro.

### `POST /efetivar` — **response body**

> **Por que este contrato é necessário neste passo:** ⚠️ **É o contrato mais importante de toda a refatoração e o único que hoje não existe no código** (`ApiResponseDto<unknown>`). Extraia o schema de resposta completo, incluindo o envelope (`sucesso`, `mensagem`) e o payload. Se o Swagger não descrever o payload, isso é um achado a levar ao time do BFF — registre e siga com o alias.

```yaml
# COLE AQUI o trecho do OpenAPI extraído do Swagger.
# Somente o path/operation/schema relevante — não o YAML inteiro.
# Resolva os $ref um nível por vez e cole os schemas referenciados abaixo.

```

**Checklist do contrato — preencha antes de escrever código:**

- [ ] O contrato acima foi extraído do Swagger na versão vigente em produção
- [ ] Todos os `$ref` citados foram resolvidos e colados
- [ ] O DTO atual no código **corresponde** ao contrato — divergência é achado, registre antes de seguir
- [ ] Campos obrigatórios no contrato estão obrigatórios no DTO (sem `?` indevido)

---

## 2. Por que este passo existe

A cadeia Confirmação é a única da aplicação com **efeito irreversível** — `POST /efetivar` efetiva a renegociação — e é a única **sem contrato de resposta**.

Hoje o service tipa o retorno como `ApiResponseDto<unknown>` e o store, no bloco `tapResponse`, nem declara o parâmetro da resposta: `next: () => {...}`. Os campos `sucesso` e `mensagem` do envelope **nunca são lidos**.

A consequência prática é um bug em produção: **o app não consegue distinguir "renegociação efetivada" de "backend recusou e devolveu HTTP 200".** Nos dois casos o usuário é levado para a tela de conclusão.

Este passo dá nome ao envelope de resposta e move a decisão de "isso foi de fato confirmado" para o `ConfirmacaoFeatureService` criado no Passo 3 — não para o store, que voltaria a acumular regra de negócio.

---

## 3. Regra de camada

Toda ficha da seção 4 aplica este contrato. Quando a ficha diz "camada: domain" ou "camada: feature", é por causa desta tabela.

| Camada | O que é dono | O que **nunca** faz |
|---|---|---|
| **DTO** (`models/dto`) | Declarar o shape de um request ou response de UMA fronteira | Fabricar objeto, decidir regra, importar entity |
| **Mapper** (`mappers`) | Traduzir DTO ↔ Entity, nas duas direções | Buscar dado, decidir regra de negócio, importar tipo de UI |
| **Entity** (`models/entities`) | Estrutura de domínio | I/O, formatação de apresentação |
| **Service de API** (`core/services/api`) | Acesso HTTP a um endpoint | Regra de negócio, composição entre domínios |
| **Service de feature** (`features/<nome>`) | Decisão de negócio e orquestração entre domínios | I/O direto |

**Por que a decisão não pode ficar no mapper?** Mapper traduz o que já recebeu. Se ele decide *qual* contrato é o principal, passa a ter duas razões para mudar — o formato do payload e a regra de negócio — e deixa de ser testável sem mockar decisão.

**Por que a decisão não volta para o store?** As camadas de view e facade foram removidas e não voltam. Regra de negócio de uma jornada vive em service de feature — é o que substituiu a facade. O store guarda estado e chama quem decide.

---

## 4. Fichas de alteração

Cada ficha traz: camada e justificativa · responsabilidade · membros públicos (só assinatura) · dependências · de onde o código sai · por quê. **Impacto colateral** lista arquivos que a ficha obriga a mexer e que não aparecem no título dela.

#### `src/app/models/dto/confirmacao-response.dto.ts` — CRIAR

- **Camada**: domain (DTO).
- **Responsabilidade**: nomear o envelope de resposta de `/efetivar`, hoje anônimo como `ApiResponseDto<unknown>` inline no service.
- **Membros públicos**:
  - `type ConfirmacaoResponseDto = ApiResponseDto<unknown>`
- **Dependências**: importa `ApiResponseDto` de `@app/models/dto/api-response.dto`.
- **Sai de onde**: não é código movido — é extração de um tipo hoje inline em `ConfirmacaoService.confirmarRenegociacao`.
- **Por que**: fecha a Ausência #3 do plano — dar nome de domínio ao contrato de resposta da única chamada irreversível, em vez de `unknown` genérico disperso pelo service e pelo store.

#### confirmacao.service.ts — ALTERAR

- **Camada**: core (services/api). Continua adaptador de I/O puro — não muda de camada, só de tipo de retorno.
- **Responsabilidade**: inalterada — só HTTP POST para `/efetivar`.
- **Membros públicos**:
  - `confirmarRenegociacao(apiRequest: ConfirmacaoRequestDto): Observable<ConfirmacaoResponseDto>`
- **Dependências**: troca o import de `ApiResponseDto` por `ConfirmacaoResponseDto` de `@app/models/dto/confirmacao-response.dto`. `HttpService` continua injetado, sem mudança.
- **Sai de onde**: N/A — só retipagem da assinatura existente (L14).
- **Por que**: parte 1 da Ausência #3 — dá nome ao envelope; sozinho ainda não resolve o risco, precisa do item abaixo.

#### `src/app/features/confirmacao/confirmacao-feature.service.ts` — ALTERAR (2ª alteração, acumula com o Passo 3)

- **Camada**: feature — mesmo motivo do Passo 3: é quem já orquestra a decisão de negócio desta cadeia, então é o dono natural de "isso foi de fato confirmado".
- **Responsabilidade** (adicionada): decidir se a resposta de `/efetivar` representa sucesso real de negócio, não só HTTP 2xx.
- **Membros públicos** (adicionar):
  - `verificarSucesso(resposta: ConfirmacaoResponseDto): boolean`
- **Dependências**: importa `ConfirmacaoResponseDto` de `@app/models/dto/confirmacao-response.dto`. Nenhuma dependência nova de I/O.
- **Sai de onde**: não é código movido — é checagem que hoje não existe em lugar nenhum (`tapResponse.next` não lê o corpo).
- **Por que**: fecha a Ausência #3 por completo — "o app não tem como distinguir renegociação efetivada de backend recusou mas devolveu 200". Depende do Passo 3 existir (é o mesmo service que resolve `codigoOperacao`/contrato principal que agora também resolve sucesso, evitando essa decisão cair de volta no store).

**Impacto colateral**:

- renegociacao.store.ts (`confirmarRenegociacao`, bloco `tapResponse`) — o `next` hoje não declara parâmetro (`next: () => {...}`). Passa a declarar `next: (resposta) => {...}`, chamar `confirmacaoFeatureService.verificarSucesso(resposta)` e só then fazer `patchState(store, { renegociacaoConfirmada: true, ... })` no caminho de sucesso; caminho `sucesso: false` precisa cair em `patchState(store, { erro: true, ... })` em vez de navegar para conclusão como hoje. Motivo: é a única forma de a tipagem do Passo 4 ter efeito observável — sem essa mudança no consumidor, `ConfirmacaoResponseDto` fica tipado mas ainda ignorado, reproduzindo o mesmo defeito.

---

---

## 5. Ordem de execução

A ordem é a que o **compilador** aceita, não a ordem lógica. Cada linha pode ser aplicada isoladamente sem quebrar o build.

Regra que gerou a ordem: **criar/adicionar método → trocar quem chama → só então apagar a origem.**

| # | arquivo | ação | camada | depende de |
|---|---|---|---|---|
| 12 | `src/app/models/dto/confirmacao-response.dto.ts` | CRIAR | domain | — |
| 13 | `confirmacao.service.ts` | ALTERAR | core | #12 |
| 14 | `src/app/features/confirmacao/confirmacao-feature.service.ts` | ALTERAR | feature | #12 |
| 15 | `renegociacao.store.ts` | ALTERAR | feature | #13, #14 |

> A numeração (#) é global à refatoração completa, mantida para rastreio contra o `refatoracao-datalayer-SPEC.md`.

---

## 6. Regras de atenção deste passo

- **⚠️ Este passo altera o fluxo irreversível da aplicação.** É o único que muda o comportamento observável de `POST /efetivar`. Trate com o cuidado de uma correção de bug em produção, não de um refactor.
- **`ConfirmacaoResponseDto` nomeia o envelope, não tipa o payload.** A spec define `type ConfirmacaoResponseDto = ApiResponseDto<unknown>`. Isso cria o lugar para ler `sucesso`/`mensagem` — que é o risco real — mas o corpo continua `unknown`. **Não anuncie a ausência como fechada.** Tipar o payload de fato depende do contrato do BFF (campo abaixo); se o Swagger o descrever, aperte o tipo neste mesmo passo e atualize a spec.
- **A checagem vai para o feature service, não para o store.** Se `verificarSucesso` cair no store, o anti-padrão que o Passo 3 acabou de resolver volta.
- **O caminho de erro muda.** Hoje `tapResponse.next` não declara parâmetro e navega para conclusão sempre. Depois: declara `resposta`, chama `verificarSucesso`, e `sucesso: false` cai em `patchState(store, { erro: true })` em vez de navegar. **Este caminho precisa de teste explícito** — é o cenário que hoje não existe.

---

## 7. Critérios de aceite

1. `confirmacao.service.ts` retorna `Observable<ConfirmacaoResponseDto>`.
2. `verificarSucesso` mora no `ConfirmacaoFeatureService`, não no store.
3. `tapResponse.next` declara o parâmetro de resposta e o utiliza.
4. **Existe teste do caminho `sucesso: false`** — cenário que hoje não é coberto.
5. Recusa do backend com HTTP 200 leva a estado de erro, não à tela de conclusão. Valide em homologação com o BFF simulando recusa.
6. Se o contrato anexado descreve o payload, `ConfirmacaoResponseDto` está tipado com ele — não com `unknown`.

---

## 8. Fora do escopo deste passo

Não amplie o PR com estes itens. Estão registrados e têm dono próprio.

- **Interceptor de loading/message.** `LoadingService` e `MessageService` estão hardcoded nos seis services de dados. É acoplamento de infraestrutura, deliberadamente fora desta análise.
- **Entities com opcionais mais fracos que a garantia do mapper.** `ClienteEntity` (`nome?`, `documento?`, `tipoDocumento?`, `razaoSocial?`) e `OfertaEntity` (`valorEntrada?`, `dataEntradaParcela?`).
- **Cadeia "Histórico".** `HistoricoEntity` é interface vazia referenciada em `store.historico`, sem cadeia que a popule.
- **Limpeza sem risco** (pode ir em qualquer PR, inclusive este): deletar `core/services/api/conclusao.service.ts`, `enum-utils.service.ts` e `negociacao.entity.ts` — mortos, confirmados por busca de referências.
