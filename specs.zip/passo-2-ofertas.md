# Passo 2 — Ofertas — direção Entity→DTO do mapper

> Unidade isolada da refatoração da camada de dados. Documento autossuficiente:
> não é necessário ler os demais passos para implementar este.
> Documento de origem: `refatoracao-datalayer-SPEC.md`.

| | |
|---|---|
| **Passo** | 2 de 5 |
| **Risco** | BAIXO |
| **Depende de** | Nenhuma. Independente do Passo 1, pode rodar em paralelo. |
| **Bloqueia** | Nada. |
| **Muda comportamento?** | Nenhuma no caminho de oferta personalizada. **No caminho de oferta predefinida há mudança real**: o store hoje monta o objeto inline por literal; passa a chamar o mapper. Verifique que o payload resultante é byte-a-byte o mesmo. |

---

## 1. Contrato do BFF

Anexe abaixo o trecho do OpenAPI extraído do Swagger, **antes de começar a implementação**. Cole somente o path, a operation e os schemas realmente usados — nunca o YAML monolítico inteiro.

### `POST /simulacao` — **request body**

> **Por que este contrato é necessário neste passo:** Payload que `entityParaPredefinidaRequest` produz.

```yaml
# COLE AQUI o trecho do OpenAPI extraído do Swagger.
# Somente o path/operation/schema relevante — não o YAML inteiro.
# Resolva os $ref um nível por vez e cole os schemas referenciados abaixo.

```

### `POST /simulacao-personalizada` — **request body**

> **Por que este contrato é necessário neste passo:** Payload que `entityParaPersonalizadaRequest` produz. Confirme se o shape de `OfertaContratoDto` é mesmo distinto do de predefinida — a spec assume que sim e mantém os dois separados.

```yaml
# COLE AQUI o trecho do OpenAPI extraído do Swagger.
# Somente o path/operation/schema relevante — não o YAML inteiro.
# Resolva os $ref um nível por vez e cole os schemas referenciados abaixo.

```

**Checklist do contrato — preencha antes de escrever código:**

- [ ] O contrato acima foi extraído do Swagger na versão vigente em produção
- [ ] Todos os `$ref` citados foram resolvidos e colados
- [ ] O DTO atual no código **corresponde** ao contrato — divergência é achado, registre antes de seguir
- [ ] Campos obrigatórios no contrato estão obrigatórios no DTO (sem `?` indevido)

---

## 2. Por que este passo existe

A camada de dados tem um desvio estrutural repetido: **arquivos de DTO fabricando objeto em vez de só declarar formato.** Um DTO deveria descrever o shape de um request ou response e nada mais.

Na cadeia Ofertas, os dois arquivos de DTO de request contêm as funções `criarOfertaPredefinidaRequest` e `criarOfertaPersonalizadaRequest`, que montam o payload que o `OfertasMapper` deveria montar. Diferente de Cliente e Confirmação, **aqui não há regra de negócio embutida** — é só reshape fora de lugar. Por isso é o passo mais brando dos três.

Há um agravante próprio desta cadeia: no store, `carregarOfertasPredefinidas` importa a função mas nunca a chama — monta o objeto **inline por literal**, duplicando o mesmo shape em dois lugares. Corrigir isso faz parte do passo; caso contrário o vazamento sobrevive e o import fica morto.

---

## 3. Regra de camada

Toda ficha da seção 4 aplica este contrato. Quando a ficha diz "camada: domain" ou "camada: feature", é por causa desta tabela.

| Camada | O que é dono | O que **nunca** faz |
|---|---|---|
| **DTO** (`models/dto`) | Declarar o shape de um request ou response de UMA fronteira | Fabricar objeto, decidir regra, importar entity |
| **Mapper** (`mappers`) | Traduzir DTO ↔ Entity, nas duas direções | Buscar dado, decidir regra de negócio, importar tipo de UI |
| **Entity** (`models/entities`) | Estrutura de domínio | I/O, formatação de apresentação |
| **Service de API** (`core/services/api`) | Acesso HTTP a um endpoint | Regra de negócio, composição entre domínios |
| **Service de feature** (`features/<nome>`) | Decisão de negócio e orquestração entre domínios | I/O direto |

**Por que a decisão não pode ficar no mapper?** Mapper traduz o que já recebeu. Se ele decide *qual* contrato é o principal, passa a ter duas razões para mudar — o formato do payload e a regra de negócio — e deixa de ser testável sem mockar decisão.

**Por que a decisão não volta para o store?** As camadas de view e facade foram removidas e não voltam. Regra de negócio de uma jornada vive em service de feature — é o que substituiu a facade. O store guarda estado e chama quem decide.

---

## 4. Fichas de alteração

Cada ficha traz: camada e justificativa · responsabilidade · membros públicos (só assinatura) · dependências · de onde o código sai · por quê. **Impacto colateral** lista arquivos que a ficha obriga a mexer e que não aparecem no título dela.

#### ofertas.mapper.ts — ALTERAR

- **Camada**: domain (mapper). Mesma razão do Passo 1 — mapper já existente vira dono das duas direções.
- **Responsabilidade**: dono único da tradução `OfertaEntity` ↔ DTOs de oferta (leitura e escrita, predefinida e personalizada).
- **Membros públicos** (adicionar aos existentes):
  - `static entityParaPredefinidaRequest(numeroAcordo: string, conta: OfertaContaDto, contratos: OfertaContratoDto[], codigoEmpresa: string): OfertaPredefinidaRequestDto`
  - `static entityParaPersonalizadaRequest(numeroAcordo: string, contratos: OfertaContratoDto[], valorEntrada?: number, taxaJuros?: number, dataVencimentoParcela?: string, valorParcela?: number | null, quantidadeParcelas?: number | null): OfertaPersonalizadaRequestDto`
- **Dependências**: passa a importar `OfertaContaDto`, `OfertaPredefinidaRequestDto` de `@app/models/dto/oferta-predefinida-request.dto` e `ENUM_ACORDO_A_VISTA`, `OfertaPersonalizadaRequestDto` de `@app/models/dto/oferta-personalizada-request.dto` (o `OfertaContratoDto` de personalizada tem shape próprio, com `parcela?`, distinto do de predefinida — mantém os dois nomes/importações separados, sem unificar por simetria).
- **Sai de onde**: oferta-predefinida-request.dto.ts função `criarOfertaPredefinidaRequest`; oferta-personalizada-request.dto.ts função `criarOfertaPersonalizadaRequest`. Corpo inalterado nos dois casos.
- **Por que**: fecha a Ausência #1 nas duas cadeias de Ofertas (padrão A do fechamento de sessão) — mesmo desvio estrutural do Cliente, "só shape, sem regra".

#### oferta-predefinida-request.dto.ts — ALTERAR

- **Camada**: domain (DTO).
- **Responsabilidade**: descrever só o shape de `OfertaPredefinidaRequestDto` (+ `OfertaContaDto`, `OfertaContratoDto`).
- **Membros públicos**: `interface OfertaContaDto`, `interface OfertaContratoDto`, `interface OfertaPredefinidaRequestDto` — todas mantidas como estão.
- **Dependências**: nenhuma (a função removida não tinha import externo).
- **Sai de onde**: N/A — remoção de `criarOfertaPredefinidaRequest`.
- **Por que**: mesmo motivo do DTO de Cliente — arquivo de DTO não fabrica objeto, só declara shape.

#### oferta-personalizada-request.dto.ts — ALTERAR

- **Camada**: domain (DTO).
- **Responsabilidade**: descrever só o shape de `OfertaPersonalizadaRequestDto` (+ `ENUM_ACORDO_A_VISTA`, `OfertaContratoDto`).
- **Membros públicos**: `enum ENUM_ACORDO_A_VISTA`, `interface OfertaContratoDto`, `interface OfertaPersonalizadaRequestDto` — mantidas.
- **Dependências**: nenhuma.
- **Sai de onde**: N/A — remoção de `criarOfertaPersonalizadaRequest`.
- **Por que**: idem.

**Impacto colateral**:

- renegociacao.store.ts — `carregarOfertasPersonalizadas` troca o import de `criarOfertaPersonalizadaRequest` por `OfertasMapper` (já importado na L11) e a chamada vira `OfertasMapper.entityParaPersonalizadaRequest(...)` com os mesmos argumentos posicionais.
- renegociacao.store.ts (`carregarOfertasPredefinidas`) — **achado não listado no plano/vereditos, mesmo defeito em outro ponto**: a função `criarOfertaPredefinidaRequest` é importada (L12) mas nunca chamada; o store monta o objeto `OfertaPredefinidaRequestDto` inline por literal, duplicando o mesmo shape que a função (e agora o mapper) já resolve. Trocar o literal inline pela chamada a `OfertasMapper.entityParaPredefinidaRequest(...)` é necessário aqui — senão o mesmo vazamento de shape sobrevive num segundo lugar, e o import antigo fica morto. Root cause, não só o caminho que o plano citou.
- Remover o import não usado de `OfertaPredefinidaRequestDto`/`OfertaPersonalizadaRequestDto` como tipo solto no store, se a tipagem de retorno do mapper já cobrir a variável local.

---

---

## 5. Ordem de execução

A ordem é a que o **compilador** aceita, não a ordem lógica. Cada linha pode ser aplicada isoladamente sem quebrar o build.

Regra que gerou a ordem: **criar/adicionar método → trocar quem chama → só então apagar a origem.**

| # | arquivo | ação | camada | depende de |
|---|---|---|---|---|
| 4 | `ofertas.mapper.ts` | ALTERAR | domain | — |
| 5 | `renegociacao.store.ts` | ALTERAR | feature | #4 |
| 6 | `oferta-predefinida-request.dto.ts` | ALTERAR | domain | #5 |
| 7 | `oferta-personalizada-request.dto.ts` | ALTERAR | domain | #5 |

> A numeração (#) é global à refatoração completa, mantida para rastreio contra o `refatoracao-datalayer-SPEC.md`.

---

## 6. Regras de atenção deste passo

- **Não unifique `OfertaContratoDto` das duas cadeias.** O shape de personalizada tem `parcela?`, o de predefinida não. São contratos distintos que coincidem parcialmente — unificar por simetria cria acoplamento entre dois endpoints que mudam por motivos diferentes. Mantenha os dois nomes e os dois imports.
- **Achado extra, obrigatório neste passo:** `carregarOfertasPredefinidas` no store importa `criarOfertaPredefinidaRequest` mas **nunca a chama** — monta o objeto inline por literal. Trocar esse literal pela chamada ao mapper faz parte do passo. Sem isso o vazamento sobrevive em outro lugar e o import fica morto.
- **Este passo não tem regra de negócio.** É só reshape. Se ao mover você encontrar uma decisão, ela não estava mapeada — pare e registre antes de seguir.

---

## 7. Critérios de aceite

1. Os dois arquivos de DTO de oferta não exportam nenhuma função.
2. `ofertas.mapper.ts` tem as duas direções para os dois endpoints.
3. `carregarOfertasPredefinidas` no store chama o mapper — **não** monta objeto inline.
4. Os payloads de `/simulacao` e `/simulacao-personalizada` são idênticos aos anteriores.
5. Nenhum import morto sobrou no store.
6. Build passa em cada linha da ordem de execução, isoladamente.

---

## 8. Fora do escopo deste passo

Não amplie o PR com estes itens. Estão registrados e têm dono próprio.

- **Interceptor de loading/message.** `LoadingService` e `MessageService` estão hardcoded nos seis services de dados. É acoplamento de infraestrutura, deliberadamente fora desta análise.
- **Entities com opcionais mais fracos que a garantia do mapper.** `ClienteEntity` (`nome?`, `documento?`, `tipoDocumento?`, `razaoSocial?`) e `OfertaEntity` (`valorEntrada?`, `dataEntradaParcela?`).
- **Cadeia "Histórico".** `HistoricoEntity` é interface vazia referenciada em `store.historico`, sem cadeia que a popule.
- **Limpeza sem risco** (pode ir em qualquer PR, inclusive este): deletar `core/services/api/conclusao.service.ts`, `enum-utils.service.ts` e `negociacao.entity.ts` — mortos, confirmados por busca de referências.
