# Passo 5 — Dívidas — separar apresentação do mapper de dados

> Unidade isolada da refatoração da camada de dados. Documento autossuficiente:
> não é necessário ler os demais passos para implementar este.
> Documento de origem: `refatoracao-datalayer-SPEC.md`.

| | |
|---|---|
| **Passo** | 5 de 5 |
| **Risco** | MÉDIO |
| **Depende de** | Nenhuma. Totalmente independente dos passos 1–4, pode rodar em paralelo. |
| **Bloqueia** | Nada. |
| **Muda comportamento?** | Nenhuma. Refactor puro de organização — as funções movem de arquivo com corpo inalterado. |

---

## 1. Contrato do BFF

Anexe abaixo o trecho do OpenAPI extraído do Swagger, **antes de começar a implementação**. Cole somente o path, a operation e os schemas realmente usados — nunca o YAML monolítico inteiro.

### `GET /dividas` — **response body**

> **Por que este contrato é necessário neste passo:** Só para confirmar o que **permanece** em `DividasMapper.dtoParaEntity`. Este passo não altera a tradução DTO→Entity; o contrato serve de baliza para garantir que nada dela foi movido por engano.

```yaml
# COLE AQUI o trecho do OpenAPI extraído do Swagger.
# Somente o path/operation/schema relevante — não o YAML inteiro.
# Resolva os $ref um nível por vez e cole os schemas referenciados abaixo.

```

**Checklist do contrato — preencha antes de escrever código:**

- [ ] O contrato acima foi extraído do Swagger na versão vigente em produção
- [ ] Todos os `$ref` citados foram resolvidos e colados
- [ ] O DTO atual no código **corresponde** ao contrato — divergência é achado, registre antes de seguir
- [ ] Campos obrigatórios no contrato estão obrigatórios no DTO (sem `?` indevido)

---

## 2. Por que este passo existe

Achado isolado da cadeia Dívidas, sem paralelo nas demais: o `DividasMapper` — artefato da camada de dados — **importa tipo de componente de UI** (`GrupoDividasView`, declarado dentro de `tabela-contratos.component.ts`).

Isso inverte a dependência: o dado passa a depender da apresentação. Qualquer mudança no componente de tabela obriga a mexer no mapper que traduz o contrato do BFF, e vice-versa.

Junto vêm dois efeitos colaterais: regra de negócio de exibição embutida no mapper (`ondeRenegociar`) e uma função que reconstrói entity a partir de view fabricando valores zerados (`viewParaEntity`).

Este passo separa o mapper em dois: o de **dados** (`DTO → Entity`, fica onde está) e o de **apresentação** (`Entity ↔ View`, vai para a feature). É independente dos passos 1–4 e pode rodar em paralelo.

---

## 3. Regra de camada

Toda ficha da seção 4 aplica este contrato. Quando a ficha diz "camada: domain" ou "camada: feature", é por causa desta tabela.

| Camada | O que é dono | O que **nunca** faz |
|---|---|---|
| **DTO** (`models/dto`) | Declarar o shape de um request ou response de UMA fronteira | Fabricar objeto, decidir regra, importar entity |
| **Mapper** (`mappers`) | Traduzir DTO ↔ Entity, nas duas direções | Buscar dado, decidir regra de negócio, importar tipo de UI |
| **Entity** (`models/entities`) | Estrutura de domínio | I/O, formatação de apresentação |
| **Service de API** (`core/services/api`) | Acesso HTTP a um endpoint | Regra de negócio, composição entre domínios |
| **Service de feature** (`features/<nome>`) | Decisão de negócio e orquestração entre domínios | I/O direto |

**Por que a decisão não pode ficar no mapper?** Mapper traduz o que já recebeu. Se ele decide *qual* contrato é o principal, passa a ter duas razões para mudar — o formato do payload e a regra de negócio — e deixa de ser testável sem mockar decisão.

**Por que a decisão não volta para o store?** As camadas de view e facade foram removidas e não voltam. Regra de negócio de uma jornada vive em service de feature — é o que substituiu a facade. O store guarda estado e chama quem decide.

---

## 4. Fichas de alteração

Cada ficha traz: camada e justificativa · responsabilidade · membros públicos (só assinatura) · dependências · de onde o código sai · por quê. **Impacto colateral** lista arquivos que a ficha obriga a mexer e que não aparecem no título dela.

#### Critério de corte (o que fica e o que sai do `DividasMapper`)

**Fica no `DividasMapper`**: qualquer função cuja entrada e saída sejam tipos de contrato/domínio (`ListagemDividasResponseDto`, `DividaEntity`). Teste: se a função não importa nem `DividaView` nem `GrupoDividasView`, ela fica. Só sobra `dtoParaEntity`.

**Vai para o adapter de apresentação**: qualquer função que produza ou consuma `DividaView`/`GrupoDividasView` — são view-model de UI (o próprio `GrupoDividasView` vive dentro de um `.component.ts` em `shared/components/tabela-contratos`), não contrato de backend. Isso puxa `entityParaGrupoView`, `entityParaView` e `viewParaEntity` inteiras, e `ondeRenegociar` junto (está inline no corpo de `entityParaView`, não é chamada externa — move com a função).

**Não entra no escopo deste passo** (fica registrado, não corrigido agora): a formatação de `periodicidade` por regex, embutida no mesmo `entityParaView`, é formatação de string e candidata a pipe/util de shared segundo o veredito — mas o passo 5 do plano pede mover a função inteira para o adapter, não fatiar a formatação num terceiro artefato. Ela migra junto com `entityParaView` para o adapter e continua lá até (se um dia) virar pipe — não invento essa ficha agora porque o plano não pediu. Da mesma forma, o achado "reconstrução com perda de dado" (`viewParaEntity` fabricando zeros) move de local mas o corpo não muda — corrigir a fabricação de zeros é achado à parte, não pedido neste passo.

---

#### dividas.mapper.ts — ALTERAR
- **Camada**: domain (mapper). Critério: só o que traduz o contrato de backend (`ListagemDividasResponseDto`) para o domínio (`DividaEntity`) fica aqui.
- **Responsabilidade**: tradução `ListagemDividasResponseDto` → `DividaEntity[]`. Só isso.
- **Membros públicos**:
  - `static dtoParaEntity(dados: ListagemDividasResponseDto | null): DividaEntity[]`
- **Dependências**: mantém `GenerateSecureIdService`, `ListagemDividasResponseDto`, `DividaEntity`. Remove os imports de `DividaView` (`@app/models/view-model/divida.view.model`) e `GrupoDividasView` (`@app/shared/components/tabela-contratos/tabela-contratos.component`) — é a própria correção do achado: mapper de dado não deveria importar tipo de UI.
- **Sai de onde**: N/A para este arquivo — é o que resta depois da remoção de `entityParaGrupoView`, `entityParaView`, `viewParaEntity`.
- **Por que**: fecha o achado PONTUAL do vereditos-datalayer.md — "mapper da camada de dados importando tipo de componente é inversão de dependência — dado depende de UI, não o contrário".

#### `src/app/features/dividas/dividas-apresentacao.mapper.ts` — CRIAR
- **Camada**: feature. Não é `shared` porque precisa conhecer `DividaEntity` (tipo de domínio) — se fosse para shared, inverteria a dependência de novo (shared conhecendo entidade de domínio). Não é `domain/mappers` porque o par de tipos que produz/consome (`DividaView`, `GrupoDividasView`) é view-model de apresentação, não contrato de backend.
- **Responsabilidade**: traduzir `DividaEntity` ↔ view-model de apresentação (`DividaView`/`GrupoDividasView`) usado pela tabela de contratos, incluindo a regra de exibição "RECR antigo/novo".
- **Membros públicos**:
  - `static entityParaGrupoView(dados: DividaEntity[][]): GrupoDividasView[]`
  - `static entityParaView(dados: DividaEntity[]): DividaView[]`
  - `static viewParaEntity(dados: DividaView[]): DividaEntity[]`
- **Membros privados**:
  - `private static ondeRenegociar(restricoes: DividaEntity['restricoes']): string`
- **Dependências**: importa `DividaEntity` de `@app/models/entities/divida.entity`, `DividaView` de `@app/models/view-model/divida.view.model`, `GrupoDividasView` de `@app/shared/components/tabela-contratos/tabela-contratos.component`. Não importa `GenerateSecureIdService` nem `ListagemDividasResponseDto` — não traduz DTO, só view.
- **Sai de onde**: dividas.mapper.ts — `entityParaGrupoView`, `entityParaView` (incluindo a expressão inline de `ondeRenegociar`, extraída para o método privado acima, e a regex de `periodicidade`, que permanece inline dentro de `entityParaView` neste destino) e `viewParaEntity`, corpos inalterados.
- **Por que**: fecha o achado PONTUAL — "`DividasMapper` importa tipo de componente de UI, embute regra de negócio de exibição (`ondeRenegociar`) e reconstrói entity com valores zerados a partir de view (`viewParaEntity`)". Isolar em artefato de feature significa que mudança no componente `tabela-contratos` não obriga mexer no mapper de dado, e vice-versa.

**Impacto colateral**:
- dividas.service.ts (`obterListagemDividas`) — troca import de `DividasMapper` por `DividasApresentacaoMapper` nas três chamadas (`entityParaGrupoView` e as duas `entityParaView`). Motivo: é consumidor direto das funções movidas.
- dividas.component.ts (`selectedContratos`) — troca `DividasMapper.viewParaEntity(data)` por `DividasApresentacaoMapper.viewParaEntity(data)`. Motivo: único outro chamador de `viewParaEntity`.
- dividas.mapper.spec.ts — os testes de `entityParaView`/`viewParaEntity` (L277+) saem deste spec e migram para um spec novo do adapter (`dividas-apresentacao.mapper.spec.ts`); o spec de `DividasMapper` fica só com os casos de `dtoParaEntity`. Motivo: spec deve testar o artefato onde o código de fato mora.
- dividas.service.spec.ts — o mock `jest.spyOn(DividasMapper.entityParaGrupoView...)` precisa apontar para `DividasApresentacaoMapper`. Motivo: mock hoje aponta para o artefato de origem, que deixa de ter o método.

---

---

## 5. Ordem de execução

A ordem é a que o **compilador** aceita, não a ordem lógica. Cada linha pode ser aplicada isoladamente sem quebrar o build.

Regra que gerou a ordem: **criar/adicionar método → trocar quem chama → só então apagar a origem.**

| # | arquivo | ação | camada | depende de |
|---|---|---|---|---|
| 16 | `src/app/features/dividas/dividas-apresentacao.mapper.ts` | CRIAR | feature | — |
| 17 | `src/app/features/dividas/dividas-apresentacao.mapper.spec.ts` | CRIAR | feature | #16 |
| 18 | `dividas.service.ts` | ALTERAR | feature | #16 |
| 19 | `dividas.component.ts` | ALTERAR | feature | #16 |
| 20 | `dividas.service.spec.ts` | ALTERAR | feature | #18 |
| 21 | `dividas.mapper.spec.ts` | ALTERAR | domain | #17, #18, #19 |
| 22 | `dividas.mapper.ts` | ALTERAR | domain | #18, #19, #20, #21 |

> A numeração (#) é global à refatoração completa, mantida para rastreio contra o `refatoracao-datalayer-SPEC.md`.

---

## 6. Regras de atenção deste passo

- **Critério de corte, em uma frase:** se a função importa `DividaView` ou `GrupoDividasView`, ela sai; se não importa, fica. Aplique o teste função a função, não por intuição.
- **`ondeRenegociar` está inline dentro de `entityParaView`**, não é chamada externa. Move junto, extraída como método privado do adapter.
- **Dois achados que movem sem correção** — registrados, não consertados agora: a formatação de `periodicidade` por regex (candidata a pipe/util, mas o passo pede mover a função inteira) e `viewParaEntity` fabricando zeros (reconstrução com perda de dado). Corpos inalterados. Corrigi-los é trabalho à parte; não amplie o escopo aqui.
- **Os testes seguem o código.** Os casos de `entityParaView`/`viewParaEntity` saem de `dividas.mapper.spec.ts` e vão para o spec novo do adapter. O spec do `DividasMapper` fica só com `dtoParaEntity`.

---

## 7. Critérios de aceite

1. `dividas.mapper.ts` não importa `DividaView` nem `GrupoDividasView`.
2. `dividas.mapper.ts` exporta apenas `dtoParaEntity`.
3. `dividas-apresentacao.mapper.ts` não importa `ListagemDividasResponseDto` nem `GenerateSecureIdService`.
4. Os testes de view estão no spec do adapter; o spec do mapper cobre só `dtoParaEntity`.
5. A tela de contratos renderiza igual — refactor sem mudança visual.
6. Build passa em cada linha da ordem de execução, isoladamente.

---

## 8. Fora do escopo deste passo

Não amplie o PR com estes itens. Estão registrados e têm dono próprio.

- **Interceptor de loading/message.** `LoadingService` e `MessageService` estão hardcoded nos seis services de dados. É acoplamento de infraestrutura, deliberadamente fora desta análise.
- **Entities com opcionais mais fracos que a garantia do mapper.** `ClienteEntity` (`nome?`, `documento?`, `tipoDocumento?`, `razaoSocial?`) e `OfertaEntity` (`valorEntrada?`, `dataEntradaParcela?`).
- **Cadeia "Histórico".** `HistoricoEntity` é interface vazia referenciada em `store.historico`, sem cadeia que a popule.
- **Limpeza sem risco** (pode ir em qualquer PR, inclusive este): deletar `core/services/api/conclusao.service.ts`, `enum-utils.service.ts` e `negociacao.entity.ts` — mortos, confirmados por busca de referências.
