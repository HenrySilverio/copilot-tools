# Refatoração da camada de dados — índice dos passos

Cinco unidades isoladas derivadas do `refatoracao-datalayer-SPEC.md`. Cada arquivo é autossuficiente: quem implementa um passo não precisa ler os outros.

Cada passo tem um campo **Contrato do BFF** na seção 1, a ser preenchido com o trecho do OpenAPI extraído do Swagger **antes** de começar a implementação.

---

## Os passos

| Arquivo | Escopo | Risco | Depende de | Contrato a extrair |
|---|---|---|---|---|
| `passo-1-cliente.md` | Direção Entity→DTO do `ClienteMapper` | BAIXO | — | `POST /atualizar-dados-cliente` (request) |
| `passo-2-ofertas.md` | Direção Entity→DTO do `OfertasMapper` | BAIXO | — | `POST /simulacao` + `POST /simulacao-personalizada` (request) |
| `passo-3-confirmacao-request.md` | Criar `ConfirmacaoMapper` + `ConfirmacaoFeatureService` | **ALTO** | — | `POST /efetivar` (request) |
| `passo-4-confirmacao-response.md` | Contrato de resposta + checagem de sucesso | **ALTO — muda comportamento** | **Passo 3** | `POST /efetivar` (**response**) |
| `passo-5-dividas.md` | Separar apresentação do mapper de dados | MÉDIO | — | `GET /dividas` (response, confirmação) |

---

## Ordem recomendada

**1 → 2 → 3 → 4**, com **5 em paralelo** a qualquer momento.

Só uma dependência é técnica: **4 depende de 3**, porque `verificarSucesso` precisa do `ConfirmacaoFeatureService` existir. As demais são de aprendizado — os passos 1 e 2 estabelecem o padrão de mapper bidirecional que o passo 3 aplica em escala maior e sob risco maior.

Passos 1, 2 e 5 são independentes entre si e podem ser distribuídos para pessoas diferentes.

---

## Antes de abrir qualquer PR

**Extraia o contrato do Swagger e cole na seção 1 do passo.** Sem isso não há como validar se o DTO ainda corresponde ao contrato do BFF — e divergência entre DTO e contrato é achado, não detalhe.

Regra de extração: cole **apenas** o path, a operation e os schemas efetivamente usados. Resolva os `$ref` um nível por vez. Nunca cole o YAML monolítico inteiro.

---

## Os dois passos que exigem atenção especial

**Passo 3 — dependência circular.** O desenho inicial fazia o mapper importar um tipo do feature service enquanto o feature service importava o mapper de volta. A spec corrige isso e a direção é de mão única: **feature service → mapper**. Se ao implementar surgir a tentação de reaproveitar o tipo do service dentro do mapper, é o ciclo voltando.

**Passo 4 — não é refactor neutro.** É o único passo que altera comportamento observável: hoje o app navega para a tela de conclusão mesmo quando o backend recusa e devolve HTTP 200; depois, `sucesso: false` cai em estado de erro. Trate como correção de bug, com teste do caminho de recusa e validação em homologação.

---

## Uso no fluxo de SDD

Cada arquivo serve como entrada de um ciclo de proposta independente. A seção 7 (**critérios de aceite**) é a candidata natural a virar os requisitos verificáveis da proposta; a seção 5 (**ordem de execução**) já traz o sequenciamento que faz cada linha compilar isoladamente.

O que **não** está nos arquivos, de propósito: implementação. As fichas trazem assinatura e contrato, nunca corpo de função. Assinatura sobrevive à implementação; código colado em documento apodrece no primeiro ajuste e vira fonte concorrente da verdade.
