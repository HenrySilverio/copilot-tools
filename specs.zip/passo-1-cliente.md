# Passo 1 — Cliente — direção Entity→DTO do mapper

> Unidade isolada da refatoração da camada de dados. Documento autossuficiente:
> não é necessário ler os demais passos para implementar este.
> Documento de origem: `refatoracao-datalayer-SPEC.md`.

| | |
|---|---|
| **Passo** | 1 de 5 |
| **Risco** | BAIXO |
| **Depende de** | Nenhuma. Pode ser o primeiro PR. |
| **Bloqueia** | Nada. |
| **Muda comportamento?** | Nenhuma. Refactor puro — mesmo payload, mesma chamada, código movido de arquivo. |

---

## 1. Contrato do BFF

Anexe abaixo o trecho do OpenAPI extraído do Swagger, **antes de começar a implementação**. Cole somente o path, a operation e os schemas realmente usados — nunca o YAML monolítico inteiro.

### `POST /atualizar-dados-cliente` — **request body**

> **Por que este contrato é necessário neste passo:** É o payload que `entityParaAtualizacaoRequest` passa a produzir. Sem ele não há como validar se `ClienteAtualizacaoRequestDto` ainda corresponde ao contrato.

```yaml
# COLE AQUI o trecho do OpenAPI extraído do Swagger.
# Somente o path/operation/schema relevante — não o YAML inteiro.
# Resolva os $ref um nível por vez e cole os schemas referenciados abaixo.

```

**Checklist do contrato — preencha antes de escrever código:**

- [ ] O contrato acima foi extraído do Swagger na versão vigente em produção
- [ ] Todos os `$ref` citados foram resolvidos e colados
- [ ] O DTO atual no código **corresponde** ao contrato — divergência é achado, registre antes de seguir
- [ ] Campos obrigatórios no contrato estão obrigatórios no DTO (sem `?` indevido)

---

## 2. Por que este passo existe

A camada de dados tem um desvio estrutural repetido: **arquivos de DTO fabricando objeto em vez de só declarar formato.** Um DTO deveria descrever o shape de um request ou response e nada mais.

Na cadeia Cliente, o `ClienteMapper` só tem a direção de leitura (`dtoParaEntity`). A direção de escrita — montar o `ClienteAtualizacaoRequestDto` a partir da entity — mora dentro do próprio arquivo de DTO, em `criarClienteAtualizacaoRequest`, junto com uma regra de negócio (`mapearTelefoneParaDto` decide fixo vs. celular pelo comprimento do número).

O mesmo desvio aparece em Ofertas (Passo 2) e, em grau mais grave, em Confirmação (Passo 3): das três cadeias que têm corpo de request, **todas as três** o exibem. É sistêmico, não pontual.

**Este passo é o mais barato dos três** — o mapper já existe, o código move sem alteração de corpo, e o diff toca dois arquivos mais o store. Serve como referência de padrão para os passos 2 e 3.

---

## 3. Regra de camada

Toda ficha da seção 4 aplica este contrato. Quando a ficha diz "camada: domain" ou "camada: feature", é por causa desta tabela.

| Camada | O que é dono | O que **nunca** faz |
|---|---|---|
| **DTO** (`models/dto`) | Declarar o shape de um request ou response de UMA fronteira | Fabricar objeto, decidir regra, importar entity |
| **Mapper** (`mappers`) | Traduzir DTO ↔ Entity, nas duas direções | Buscar dado, decidir regra de negócio, importar tipo de UI |
| **Entity** (`models/entities`) | Estrutura de domínio | I/O, formatação de apresentação |
| **Service de API** (`core/services/api`) | Acesso HTTP a um endpoint | Regra de negócio, composição entre domínios |
| **Service de feature** (`features/<nome>`) | Decisão de negócio e orquestração entre domínios | I/O direto |

**Por que a decisão não pode ficar no mapper?** Mapper traduz o que já recebeu. Se ele decide *qual* contrato é o principal, passa a ter duas razões para mudar — o formato do payload e a regra de negócio — e deixa de ser testável sem mockar decisão.

**Por que a decisão não volta para o store?** As camadas de view e facade foram removidas e não voltam. Regra de negócio de uma jornada vive em service de feature — é o que substituiu a facade. O store guarda estado e chama quem decide.

---

## 4. Fichas de alteração

Cada ficha traz: camada e justificativa · responsabilidade · membros públicos (só assinatura) · dependências · de onde o código sai · por quê. **Impacto colateral** lista arquivos que a ficha obriga a mexer e que não aparecem no título dela.

#### cliente.mapper.ts — ALTERAR

- **Camada**: domain (mapper). É onde a tradução Entity↔DTO já vive (`dtoParaEntity`); a direção inversa completa o mesmo dono.
- **Responsabilidade**: dono único da tradução bidirecional `ClienteEntity` ↔ DTOs de cliente (leitura e escrita).
- **Membros públicos** (adicionar aos existentes):
  - `static entityParaAtualizacaoRequest(email: string, telefone: ClienteEntity['dadosPessoais']['telefone'], endereco: EnderecoClienteAtualizacaoEntrada): ClienteAtualizacaoRequestDto`
- **Membros privados** (adicionar):
  - `private static mapearTelefoneParaDto(telefone: ClienteEntity['dadosPessoais']['telefone']): ClienteAtualizacaoRequestDto['telefone']`
- **Dependências**: passa a importar `ClienteAtualizacaoRequestDto` e `EnderecoClienteAtualizacaoEntrada` de `@app/models/dto/cliente-atualizacao-request.dto`. Nenhuma dependência removida.
- **Sai de onde**: cliente-atualizacao-request.dto.ts — funções `criarClienteAtualizacaoRequest` e `mapearTelefoneParaDto`, corpo inalterado.
- **Por que**: fecha a Ausência #1 do vereditos-datalayer.md — "falta a direção inversa do mapper (entity→DTO para atualização), hoje vazada para dentro do arquivo de DTO". A regra de negócio (fixo vs. celular por `length`) passa a morar no mesmo artefato que já decide o resto da tradução de Cliente.

#### cliente-atualizacao-request.dto.ts — ALTERAR

- **Camada**: domain (DTO). Contrato de shape puro, sem função.
- **Responsabilidade**: descrever só o shape de `ClienteAtualizacaoRequestDto`.
- **Membros públicos**: `interface ClienteAtualizacaoRequestDto` (mantém como está) e `interface EnderecoClienteAtualizacaoEntrada` (mantém, vira tipo de suporte usado só pelo mapper).
- **Dependências**: remove o import de `ClienteEntity` (só era usado pela assinatura das funções removidas).
- **Sai de onde**: N/A — é remoção. `criarClienteAtualizacaoRequest` e `mapearTelefoneParaDto` saem deste arquivo (vão para o mapper acima).
- **Por que**: elimina o "DTO fazendo papel de mapper" (Ausência #1, Cliente) — o arquivo volta a só descrever formato de request.

**Impacto colateral**:

- renegociacao.store.ts — troca o import de `criarClienteAtualizacaoRequest` (de `@app/models/dto/cliente-atualizacao-request.dto`) por `ClienteMapper` (já importado na L8) e a chamada `criarClienteAtualizacaoRequest(email, telefone, endereco)` vira `ClienteMapper.entityParaAtualizacaoRequest(email, telefone, endereco)`. Motivo: é o único chamador da função movida; sem essa troca o build quebra.

---

---

## 5. Ordem de execução

A ordem é a que o **compilador** aceita, não a ordem lógica. Cada linha pode ser aplicada isoladamente sem quebrar o build.

Regra que gerou a ordem: **criar/adicionar método → trocar quem chama → só então apagar a origem.**

| # | arquivo | ação | camada | depende de |
|---|---|---|---|---|
| 1 | `cliente.mapper.ts` | ALTERAR | domain | — |
| 2 | `renegociacao.store.ts` | ALTERAR | feature | #1 |
| 3 | `cliente-atualizacao-request.dto.ts` | ALTERAR | domain | #2 |

> A numeração (#) é global à refatoração completa, mantida para rastreio contra o `refatoracao-datalayer-SPEC.md`.

---

## 6. Regras de atenção deste passo

- **A regra de negócio move junto, não fica para trás.** `mapearTelefoneParaDto` decide fixo vs. celular por `length`. Essa decisão vai para o mapper como método privado — não a deixe no DTO nem a duplique no store.
- **`EnderecoClienteAtualizacaoEntrada` permanece no arquivo de DTO.** Vira tipo de suporte consumido pelo mapper. Não mova.
- **Ordem importa:** adicione o método no mapper → troque o store → só então apague do DTO. Apagar antes quebra o build.

---

## 7. Critérios de aceite

1. `cliente-atualizacao-request.dto.ts` não exporta nenhuma função — só `interface`/`type`.
2. `cliente.mapper.ts` tem as duas direções (`dtoParaEntity` e `entityParaAtualizacaoRequest`).
3. O payload enviado ao `POST /atualizar-dados-cliente` é idêntico ao anterior — compare contra o contrato anexado acima.
4. `renegociacao.store.ts` não importa mais nada de `cliente-atualizacao-request.dto`, exceto tipos.
5. Build passa em cada linha da ordem de execução, isoladamente.

---

## 8. Fora do escopo deste passo

Não amplie o PR com estes itens. Estão registrados e têm dono próprio.

- **Interceptor de loading/message.** `LoadingService` e `MessageService` estão hardcoded nos seis services de dados. É acoplamento de infraestrutura, deliberadamente fora desta análise.
- **Entities com opcionais mais fracos que a garantia do mapper.** `ClienteEntity` (`nome?`, `documento?`, `tipoDocumento?`, `razaoSocial?`) e `OfertaEntity` (`valorEntrada?`, `dataEntradaParcela?`).
- **Cadeia "Histórico".** `HistoricoEntity` é interface vazia referenciada em `store.historico`, sem cadeia que a popule.
- **Limpeza sem risco** (pode ir em qualquer PR, inclusive este): deletar `core/services/api/conclusao.service.ts`, `enum-utils.service.ts` e `negociacao.entity.ts` — mortos, confirmados por busca de referências.
