# Passo 3 — Confirmação — mapper + feature service

> Unidade isolada da refatoração da camada de dados. Documento autossuficiente:
> não é necessário ler os demais passos para implementar este.
> Documento de origem: `refatoracao-datalayer-SPEC.md`.

| | |
|---|---|
| **Passo** | 3 de 5 |
| **Risco** | ALTO |
| **Depende de** | Nenhuma tecnicamente, mas é o passo mais caro. Recomendado depois de 1 e 2, que estabelecem o padrão de mapper bidirecional. |
| **Bloqueia** | **Passo 4 depende inteiramente deste.** Sem o `ConfirmacaoFeatureService`, a checagem de sucesso do Passo 4 cairia de volta no store — mesmo anti-padrão. |
| **Muda comportamento?** | Nenhuma esperada. O payload produzido deve ser idêntico ao atual. **Este é o critério de aceite mais importante do passo.** |

---

## 1. Contrato do BFF

Anexe abaixo o trecho do OpenAPI extraído do Swagger, **antes de começar a implementação**. Cole somente o path, a operation e os schemas realmente usados — nunca o YAML monolítico inteiro.

### `POST /efetivar` — **request body**

> **Por que este contrato é necessário neste passo:** É a chamada irreversível. O `ConfirmacaoRequestDto` precisa ser validado campo a campo contra o contrato antes de mover qualquer código — um erro de reshape aqui efetiva renegociação errada.

```yaml
# COLE AQUI o trecho do OpenAPI extraído do Swagger.
# Somente o path/operation/schema relevante — não o YAML inteiro.
# Resolva os $ref um nível por vez e cole os schemas referenciados abaixo.

```

**Checklist do contrato — preencha antes de escrever código:**

- [ ] O contrato acima foi extraído do Swagger na versão vigente em produção
- [ ] Todos os `$ref` citados foram resolvidos e colados
- [ ] O DTO atual no código **corresponde** ao contrato — divergência é achado, registre antes de seguir
- [ ] Campos obrigatórios no contrato estão obrigatórios no DTO (sem `?` indevido)

---

## 2. Por que este passo existe

A camada de dados tem um desvio estrutural repetido: arquivos de DTO fabricando objeto em vez de só declarar formato. **A cadeia Confirmação é o caso extremo desse desvio e concentra três problemas ao mesmo tempo:**

1. **Não existe mapper nenhum.** O arquivo `confirmacao-request.dto.ts` faz o reshape inteiro.
2. **Decide regra de negócio.** Qual é o contrato principal (`.at(0)`), qual o `codigoOperacao` (por `tipoPrazo`), qual forma de pagamento está ativa (um `reduce`). Decisão que agrega quatro domínios — `ClienteEntity`, `ContaEntity`, `DividaEntity[]`, `OfertaEntity` — dentro de um arquivo de DTO chamado pelo store.
3. **É a única chamada irreversível da aplicação.** `POST /efetivar` efetiva a renegociação. Não há desfazer.

Não existe hoje nenhum artefato de orquestração para esta jornada — a camada de facade foi removida e nada assumiu o papel. Este passo cria os dois artefatos que faltam: um **mapper** para o reshape e um **service de feature** para a decisão.

**Os dois nascem juntos, no mesmo PR.** Criar um sem o outro apenas move o vazamento de arquivo.

---

## 3. Regra de camada

Toda ficha da seção 4 aplica este contrato. Quando a ficha diz "camada: domain" ou "camada: feature", é por causa desta tabela.

| Camada | O que é dono | O que **nunca** faz |
|---|---|---|
| **DTO** (`models/dto`) | Declarar o shape de um request ou response de UMA fronteira | Fabricar objeto, decidir regra, importar entity |
| **Mapper** (`mappers`) | Traduzir DTO ↔ Entity, nas duas direções | Buscar dado, decidir regra de negócio, importar tipo de UI |
| **Entity** (`models/entities`) | Estrutura de domínio | I/O, formatação de apresentação |
| **Service de API** (`core/services/api`) | Acesso HTTP a um endpoint | Regra de negócio, composição entre domínios |
| **Service de feature** (`features/<nome>`) | Decisão de negócio e orquestração entre domínios | I/O direto |

**Por que a decisão não pode ficar no mapper?** Mapper traduz o que já recebeu. Se ele decide *qual* contrato é o principal, passa a ter duas razões para mudar — o formato do payload e a regra de negócio — e deixa de ser testável sem mockar decisão.

**Por que a decisão não volta para o store?** As camadas de view e facade foram removidas e não voltam. Regra de negócio de uma jornada vive em service de feature — é o que substituiu a facade. O store guarda estado e chama quem decide.

---

## 4. Fichas de alteração

Cada ficha traz: camada e justificativa · responsabilidade · membros públicos (só assinatura) · dependências · de onde o código sai · por quê. **Impacto colateral** lista arquivos que a ficha obriga a mexer e que não aparecem no título dela.

#### `src/app/mappers/confirmacao.mapper.ts` — CRIAR

- **Camada**: domain (mapper). Só reshape de dado já resolvido — mesmo papel que `ClienteMapper`/`OfertasMapper` exercem nas outras cadeias.
- **Responsabilidade**: traduzir dados já decididos (contrato principal, código de operação, forma de pagamento ativa) para o shape `ConfirmacaoRequestDto`. Não decide nada, só reformata.
- **Membros públicos**:
  - `static entidadesParaRequest(dados: ConfirmacaoDadosResolvidos): ConfirmacaoRequestDto`
  - `interface ConfirmacaoDadosResolvidos { contratoPrincipal: DividaEntity | undefined; contratosSelecionados: DividaEntity[]; ofertaSelecionada: OfertaEntity | null; cliente: ClienteEntity; codigoOperacao: string; grupoContratos: string; pagamentoAtivo: { aVista?: PagamentoResolvido; entrada?: PagamentoResolvido; parcela?: PagamentoResolvido }; autorizacoesSelecionadas: [TipoAutorizacao, boolean][] }`
  - `interface PagamentoResolvido { conta: ContaEntity; metodoPagamento: TipoMetodoPagamento | null }` — shape estrutural próprio do mapper, **não** importado do feature service (ver Ponto de atenção 1)
- **Dependências**: importa `ConfirmacaoRequestDto` de `@app/models/dto/confirmacao-request.dto`; `ClienteEntity`, `DividaEntity`, `OfertaEntity`, `TipoAutorizacao`. Não injeta nada (classe estática, como os demais mappers).
- **Sai de onde**: parte **(a)** de confirmacao-request.dto.ts (`criarConfirmacaoRequest`, só os campos de reshape: `proposta`, `cliente.idEndereco`, `divida`, `autorizacoes`) e parte **(a)** de `montarPagamentoConfirmacao` (L159-210: montagem de `aVista`/`entrada`/`parcela` e formatações — uppercase de método, `.replace(/\//g,'.')`), sem o `reduce` de decisão.
- **Por que**: fecha a Ausência #1 (grau mais grave, Confirmacao) e a metade "(a) montagem de payload" do achado misto de `criarConfirmacaoRequest`/`montarPagamentoConfirmacao` no vereditos-datalayer.md — "isso é trabalho de mapper", testável sem mockar decisão de negócio.

#### `src/app/features/confirmacao/confirmacao-feature.service.ts` — CRIAR

- **Camada**: feature. É o artefato de orquestração multi-domínio que o plano diz que "não existe hoje" — não pode ser core/domain porque decide regra de negócio específica da jornada de confirmação, e não é `shared` porque não é reutilizável fora desta feature.
- **Responsabilidade**: decidir contrato principal, código de operação e forma de pagamento ativa a partir do estado da renegociação, e produzir o `ConfirmacaoRequestDto` chamando o mapper só com dados já resolvidos.
- **Membros públicos**:
  - `prepararConfirmacao(parametros: CriarConfirmacaoRequestParametros): ConfirmacaoRequestDto`
  - `interface CriarConfirmacaoRequestParametros { contratosSelecionados: DividaEntity[]; ofertaSelecionada: OfertaEntity | null; cliente: ClienteEntity; metodoFormaPagamentoSelecionada: MetodoFormaPagamentoSelecionado[] | null; autorizacoesSelecionadas: [TipoAutorizacao, boolean][] }`
  - `interface MetodoFormaPagamentoSelecionado { conta: ContaEntity; formaPagamento: TipoFormaPagamento | null; metodoPagamento: TipoMetodoPagamento | null }`
- **Membros privados**:
  - `private resolverCodigoOperacao(ofertaSelecionada: OfertaEntity | null): string`
  - `private resolverFormaPagamentoAtiva(metodoFormaPagamentoSelecionada: MetodoFormaPagamentoSelecionado[] | null): { aVista?: MetodoFormaPagamentoSelecionado; entrada?: MetodoFormaPagamentoSelecionado; parcela?: MetodoFormaPagamentoSelecionado }`
- **Dependências**: injeta `ConfirmacaoMapper` (import estático, sem DI de fato) de `@app/mappers/confirmacao.mapper`. Não injeta `HttpService`/`ConfirmacaoService` — não faz I/O, só orquestra dado em memória.
- **Sai de onde**: parte **(b)** de `criarConfirmacaoRequest` (L86 `contratoPrincipal = contratosSelecionados.at(0)`; L91 `grupoContratos ?? 0`; L92-94 `codigoOperacao` por `tipoPrazo`) e parte **(b)** de `montarPagamentoConfirmacao` (L165-172, o `reduce` que decide qual forma está ativa). Também herda os tipos `interface MetodoFormaPagamentoSelecionado` (L65-69) e `interface CriarConfirmacaoRequestParametros` (L71-77) do mesmo arquivo.
- **Por que**: fecha a Ausência #2 do plano — "decisão de negócio que agrega ClienteEntity+ContaEntity+DividaEntity[]+OfertaEntity, hoje dentro de um arquivo de DTO chamado pelo store". É o par que precisa nascer junto com o mapper acima: "criar um sem o outro reintroduz o mesmo vazamento em outro arquivo".

#### confirmacao-request.dto.ts — ALTERAR

- **Camada**: domain (DTO).
- **Responsabilidade**: descrever só o shape de `ConfirmacaoRequestDto`.
- **Membros públicos**: `interface ConfirmacaoRequestDto` (mantém como está, única sobrevivente).
- **Dependências**: remove imports de `ClienteEntity`, `ContaEntity`, `DividaEntity`, `OfertaEntity`, `TipoAutorizacao`, `TipoFormaPagamento`, `TipoMetodoPagamento` (só serviam às funções/tipos removidos). Mantém `TipoOferta`/`TipoOperacao` só se ainda referenciados — não são, então também saem.
- **Sai de onde**: N/A — remoção de `criarConfirmacaoRequest`, `montarPagamentoConfirmacao`, `interface MetodoFormaPagamentoSelecionado`, `interface CriarConfirmacaoRequestParametros`.
- **Também deletado, não movido**: `obterValorAcordoPorFormaPagamento` (L133-157) — código morto confirmado (zero chamadores no repo), não migra para lugar nenhum.
- **Por que**: fecha a Ausência #1 (o caso mais grave) e deixa o arquivo com a única responsabilidade que um DTO deveria ter.

**Impacto colateral**:

- renegociacao.store.ts (`confirmarRenegociacao`) — troca o import de `criarConfirmacaoRequest` (de `@app/models/dto/confirmacao-request.dto`) por `ConfirmacaoFeatureService` injetado, e a chamada `criarConfirmacaoRequest({...})` vira `confirmacaoFeatureService.prepararConfirmacao({...})` com os mesmos 5 campos do objeto de parâmetro. `confirmarRenegociacao(store, confirmacaoService)` (função de nível de módulo) precisa receber a nova dependência como parâmetro adicional — motivo: é o único chamador da função/tipos movidos, e a assinatura da função de store precisa do novo service para orquestrar a chamada.

---

---

## 5. Ordem de execução

A ordem é a que o **compilador** aceita, não a ordem lógica. Cada linha pode ser aplicada isoladamente sem quebrar o build.

Regra que gerou a ordem: **criar/adicionar método → trocar quem chama → só então apagar a origem.**

| # | arquivo | ação | camada | depende de |
|---|---|---|---|---|
| 8 | `src/app/mappers/confirmacao.mapper.ts` | CRIAR | domain | — |
| 9 | `src/app/features/confirmacao/confirmacao-feature.service.ts` | CRIAR | feature | #8 |
| 10 | `renegociacao.store.ts` | ALTERAR | feature | #8, #9 |
| 11 | `confirmacao-request.dto.ts` | ALTERAR | domain | #10 |

> A numeração (#) é global à refatoração completa, mantida para rastreio contra o `refatoracao-datalayer-SPEC.md`.

---

## 6. Regras de atenção deste passo

- **⚠️ Dependência circular — a armadilha principal deste passo.** O desenho inicial fazia o mapper importar `MetodoFormaPagamentoSelecionado` do feature service, enquanto o feature service importava o mapper de volta. A spec corrige isso: o mapper declara seu **próprio** shape estrutural (`PagamentoResolvido`) e não importa nada do feature service. **A dependência é de mão única: feature service → mapper.** Se ao implementar surgir a tentação de reaproveitar o tipo do service no mapper, é o ciclo voltando.
- **Os dois arquivos nascem no mesmo PR.** Criar o mapper sem o feature service (ou vice-versa) reintroduz o mesmo vazamento em outro arquivo. Não fatie este passo.
- **O corte entre reshape e decisão é o núcleo do passo.** Decisão (vai para o feature service): qual é o contrato principal (`.at(0)`), o `codigoOperacao` por `tipoPrazo`, qual forma de pagamento está ativa (o `reduce`). Reshape (vai para o mapper): tudo que só reformata dado já resolvido — uppercase de método, `.replace(/\//g,'.')`, montagem de `proposta`/`divida`/`autorizacoes`.
- **`obterValorAcordoPorFormaPagamento` é deletado, não movido.** Código morto confirmado, zero chamadores. Não o carregue para o mapper "por precaução".
- **`confirmarRenegociacao(store, confirmacaoService)` ganha um parâmetro.** É função de nível de módulo; precisa receber o `ConfirmacaoFeatureService` para orquestrar. Ajuste a assinatura e todos os chamadores.

---

## 7. Critérios de aceite

1. `confirmacao-request.dto.ts` exporta **apenas** `interface ConfirmacaoRequestDto`.
2. `confirmacao.mapper.ts` **não importa nada** de `confirmacao-feature.service.ts`. Verifique o grafo de imports, não só a leitura.
3. `obterValorAcordoPorFormaPagamento` não existe mais em lugar nenhum.
4. **O payload de `POST /efetivar` é idêntico ao anterior** — compare campo a campo contra o contrato anexado. Este é o critério mais importante.
5. Nenhuma decisão de negócio no mapper: ele não tem `if` sobre regra, `.at(0)`, nem `reduce` de seleção.
6. Build passa em cada linha da ordem de execução, isoladamente.

---

## 8. Fora do escopo deste passo

Não amplie o PR com estes itens. Estão registrados e têm dono próprio.

- **Interceptor de loading/message.** `LoadingService` e `MessageService` estão hardcoded nos seis services de dados. É acoplamento de infraestrutura, deliberadamente fora desta análise.
- **Entities com opcionais mais fracos que a garantia do mapper.** `ClienteEntity` (`nome?`, `documento?`, `tipoDocumento?`, `razaoSocial?`) e `OfertaEntity` (`valorEntrada?`, `dataEntradaParcela?`).
- **Cadeia "Histórico".** `HistoricoEntity` é interface vazia referenciada em `store.historico`, sem cadeia que a popule.
- **Limpeza sem risco** (pode ir em qualquer PR, inclusive este): deletar `core/services/api/conclusao.service.ts`, `enum-utils.service.ts` e `negociacao.entity.ts` — mortos, confirmados por busca de referências.
